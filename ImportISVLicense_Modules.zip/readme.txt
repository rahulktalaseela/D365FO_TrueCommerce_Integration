1. extract the package
2. put the isv license file into the AosService\Scripts\License folder
3. zip up the package and you can follow the standard instruction to deploy the deployable package to your AX topology